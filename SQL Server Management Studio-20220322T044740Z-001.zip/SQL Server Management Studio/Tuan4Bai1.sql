-- b�i 1

CREATE TABLE GiaoVien (
	GV# char(4) NOT NULL,
	HoTen nvarchar(30) NOT NULL,
	DiaChi nvarchar(50),
	NamSinh integer,
	CONSTRAINT KhoachinhG primary key(GV#)
);

CREATE TABLE DeTai(
	DT# char(4) NOT NULL,
	TenDT nvarchar(30) NOT NULL,
	TheLoai nvarchar(20),
	CONSTRAINT KhoachinhD primary key(DT#)
);

CREATE TABLE SinhVien(
	SV# char(4) NOT NULL,
	TenSV nvarchar(30) NOT NULL,
	NgaySinh date,
	QueQuan nvarchar(20),
	Lop nvarchar(20),
	CONSTRAINT KhoaChinhS primary key(SV#)
)

CREATE TABLE HuongDan(
	GV# char(4) NOT NULL,
	DT# char(4) NOT NULL,
	SV# char(4) NOT NULL,
	NamThucHien int,
	KetQua float,
	primary key(GV#, DT#, SV#, NamThucHien),
	foreign key(GV#) references GiaoVien (GV#),
	foreign key(DT#) references DeTai(DT#),
	foreign key(SV#) references SinhVien(SV#)
);

select * from GiaoVien
drop table HuongDan


